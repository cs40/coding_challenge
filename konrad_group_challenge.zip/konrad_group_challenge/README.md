# KonradGroupCodingChallenge

#### Getting Started

Follow the steps below:

```
> npm install
> npm start
```

Go to localhost:8080

Thank you for the opportunity.