import React, { Component} from 'react';
import _ from 'lodash';
import ReactDOM from 'react-dom';
import axios from 'axios';
import DateSelector from './components/date_selector';
import GamesList from './components/games_list';
import InningsTable from './components/home_run_table';

class App extends Component  {
  constructor(props){
    super(props);

    this.state = {
      date: null,
      games: [],
      selectedGame:null
    };

    this.getGameData('2014-03-29');

  }

  //get data from API based on date inputted
  getGameData = (date) => {
    let parsedDate = date.split("-")
    axios.get(`http://gd2.mlb.com/components/game/mlb/year_${parsedDate[0]}/month_${parsedDate[1]}/day_${parsedDate[2]}/master_scoreboard.json`)
      .then((response) => {
        var data = response.data.data.games.game
        //if games is null we can notify user
        if (typeof data == 'undefined') {
          this.setState({
            date: date,
            games: null
          })
        } else if (data.constructor == Array) {
          //we can just games to the data list
          //make sure Blue Jays games are first
          var jaysGames = data.filter(game => {
            if (game.home_team_name === "Blue Jays" || game.away_team_name === "Blue Jays") {
              
              return true
            }
            return false
          })

          var otherGames = data.filter(game => {
            if (game.home_team_name !== "Blue Jays" || game.away_team_name !== "Blue Jays") {
              return true
            }
            return false
          })

          console.log(jaysGames)
          console.log(otherGames)
          this.setState({
            date: date,
            games: [...jaysGames, ...otherGames]
          })
         
        } else {
          //need to push the data to a list first
          let gamesList = []
          gamesList.push(data)
          this.setState({
            date: date,
            games: data
          })
          console.log(this.state.games)
        }
        
      })
      .catch((error) => {
        console.log(error)
      })
  }

  render(){
    //dont want to make API call on every input change
    const dateSearch = _.debounce((date) => {this.getGameData(date)}, 700);
    
    if (this.state.selectedGame == null) {
      return(
        <div>
          <DateSelector date={this.state.date} dateSearch={dateSearch}/>
          <GamesList
            onGameSelect = {selectedGame => this.setState({selectedGame})}
            games = {this.state.games}/>
        </div>
      );
    } else {
      return (
        <div>
          <InningsTable/>
        </div>
      )
    }
    
    }
}


ReactDOM.render(<App/>, document.querySelector('.container'));