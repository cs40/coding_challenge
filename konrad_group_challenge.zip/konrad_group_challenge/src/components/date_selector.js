import React, { Component } from 'react';
import { Input } from 'semantic-ui-react'

class DateSelector extends Component {
  constructor(props){
    super(props);;
    this.state = {
      searchDate: null

    };
  }

  onInputChange = (date) => {
      this.props.dateSearch(date)
  }
  render() {
    return (
      
      <div>
        <div>
         <p> Enter date in the format yyyy-dd-mm</p>
        </div>

        <Input 
          icon='search' 
          placeholder={this.props.date} 
          onChange={event=> this.onInputChange( event.target.value )} />
      </div>
    );
  }



}

export default DateSelector;