import React from 'react';
import { List } from 'semantic-ui-react'

const GameItem = ({game, onGameSelect}) => {
//Check if the game was completed and include score
if (game.linescore){
  return (
    <List.Item onClick={()=> onGameSelect(game)}> 
      <List.Item> 
        {game.home_team_name} 
        <List.Content floated='right'>
          {game.linescore.hr.home}
        </List.Content> 
      </List.Item> 
      <List.Item> 
        {game.away_team_name}  
        <List.Content floated='right'>
          {game.linescore.hr.away}
        </List.Content> 
      </List.Item> 
      <List.Item> {game.status.status}  </List.Item> 
     </List.Item>
  );
}
//Game does not ahve a final score
else {
  return (
    <List.Item onClick={()=> onGameSelect(game)}> 
      <List.Item> 
        {game.home_team_name}   
      </List.Item> 
      <List.Item> 
        {game.away_team_name}      
      </List.Item> 
      <List.Item> {game.status.status}  </List.Item> 
        
     </List.Item>
  );
}
}

export default GameItem;