import React, { Component } from 'react';
import GameItem from './game_item';
import { List } from 'semantic-ui-react';

const GameList = (props) => {

  const games =  props.games.map((game) => {
    console.log('here')
    console.log(game.id)
    return <GameItem
      onGameSelect = {props.onGameSelect}
      key={game.id}
      game = {game} />
  })
  return (
    <List celled>
      {games}
    </List>
  );
};

export default GameList;